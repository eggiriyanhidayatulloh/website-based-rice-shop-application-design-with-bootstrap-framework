<h2><center>Selamat Datang Administrator</center></h2>
<!-- <pre><?php print_r($_SESSION); ?></pre> -->
<br><br>
<div>
	<div>
	<img src="foto/padi.jpg" width="100%" height="100%">	
	</div>
</div>